const toggle = document.getElementById('langToggle');
const year = document.getElementById('year');
year.textContent = new Date().getFullYear();
let english = false;
toggle.addEventListener('click', () => {
  english = !english;
  document.documentElement.lang = english ? 'en' : 'fa';
  document.documentElement.dir = english ? 'ltr' : 'rtl';
  document.body.classList.toggle('en', english);
  document.querySelectorAll('[data-fa][data-en]').forEach(el => {
    el.textContent = english ? el.dataset.en : el.dataset.fa;
  });
  toggle.textContent = english ? 'FA' : 'EN';
});
